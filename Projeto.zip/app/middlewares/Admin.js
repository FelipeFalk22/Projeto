module.exports = (req, res, next) => {
  if (!req.usuario || req.usuario.tipo !== 'admin') {
    return res.status(403).json({
      message: 'Apenas administradores podem acessar esta funcionalidade.'
    });
  }
  next();
};
