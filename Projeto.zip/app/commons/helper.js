const config = require('../../config.js');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// ⚠️ SOMENTE PARA TESTES NO POSTMAN (mantido, mas agora sem expor a chave real)
console.log('🔐 Middleware JWT carregado. Ambiente:', process.env.NODE_ENV || 'dev');

exports.hashSenha = (senha) => {
  const hash = crypto.createHash('sha256');
  hash.update(senha);
  return hash.digest('hex');
};

exports.gerarTokenAcesso = (nome, id, tipo) => {
  return jwt.sign(
    { nome, id, tipo },
    config.jwt.secret,
    { expiresIn: config.jwt.expiration }
  );
};
