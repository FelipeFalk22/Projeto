module.exports = {
  type: 'object',
  properties: {
    protocolo: { type: 'string', minLength: 3 }, // ✔ correção real
    descricao: { type: 'string', minLength: 3 },
    status: {
      type: 'string',
      enum: ['aberto', 'em andamento', 'fechado']
    }
  },
  required: ['protocolo', 'descricao', 'status'], // ✔ corrigido
  additionalProperties: false
};
