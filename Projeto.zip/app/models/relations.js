module.exports = (models) => {
  const CategoriaModel = models.CategoriaModel;   // ✔ corrigido
  const ChamadoModel = models.ChamadoModel;       // ✔ corrigido

  CategoriaModel.hasMany(ChamadoModel, {
    foreignKey: 'id_categoria',
    as: 'chamados',
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE'
  });

  ChamadoModel.belongsTo(CategoriaModel, {
    foreignKey: 'id_categoria',
    as: 'categoria'
  });
};
