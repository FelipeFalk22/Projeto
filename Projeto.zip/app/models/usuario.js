const Sequelize = require('sequelize');
const db = require('./conexao.js');

class Usuario {
  #nome;
  #email;
  #senha;
  #tipo;

  constructor() {}

  get nome() { return this.#nome; }
  set nome(nome) { this.#nome = nome; }

  get email() { return this.#email; }
  set email(email) { this.#email = email; }

  get senha() { return this.#senha; }
  set senha(senha) { this.#senha = senha; }

  get tipo() { return this.#tipo; }
  set tipo(tipo) { this.#tipo = tipo; }

  static async create(novoUsuario) {
    return await UsuarioModel.create({
      nome: novoUsuario.nome,
      email: novoUsuario.email,
      senha: novoUsuario.senha,
      tipo: novoUsuario.tipo || 'user'
    });
  }

  static async findOne(dados) {
    return await UsuarioModel.findOne({ where: dados });
  }
}

const UsuarioModel = db.define('usuario', {
  id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
  nome: { type: Sequelize.STRING(200), allowNull: false },
  email: { type: Sequelize.STRING(80), allowNull: false, unique: true },
  senha: { type: Sequelize.STRING(64), allowNull: false },    // ✔ ajustado p/ bater com o banco
  tipo: { type: Sequelize.STRING(20), allowNull: false, defaultValue: 'user' }
});

module.exports = UsuarioModel;   // ✔ corrigido (exporta apenas o que o controller espera)
