const conexao = require('./conexao.js');

// Agora cada require já retorna diretamente o Model (corrigido nos arquivos anteriores)
const Usuario = require('./Usuario.js');
const Categoria = require('./Categoria.js');
const Chamado = require('./Chamado.js');

const relations = require('./relations.js');

const db = {};

// ✔ corrigido: agora cada um é o Model correto
db.usuario = Usuario;
db.categoria = Categoria;
db.chamado = Chamado;

// ✔ corrigido: relations recebe os models corretos
relations({
  CategoriaModel: Categoria,
  ChamadoModel: Chamado
});

// sincronizar (comentado para não duplicar sync no servidor)
/// conexao.sync({});

module.exports = db;
