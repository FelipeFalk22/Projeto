const Sequelize = require('sequelize');
const db = require('./conexao.js');

const CategoriaModel = db.define('categoria', {
  id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
  nome: { type: Sequelize.STRING(200), allowNull: false },
  descricao: { type: Sequelize.STRING(255), allowNull: false }
});

class Categoria {
  static create(data) {
    return CategoriaModel.create(data);
  }

  static findByPk(id) {
    return CategoriaModel.findByPk(id);
  }

  static findAll() {     // ✔ corrigido — não aceita parâmetro inexistente
    return CategoriaModel.findAll();
  }

  static update(dados, id) {
    return CategoriaModel.update(dados, { where: { id } });
  }

  static async delete(id) {
    const cat = await CategoriaModel.findByPk(id);
    if (!cat) return false;
    await cat.destroy();
    return true;
  }
}

module.exports = CategoriaModel;   // ✔ corrigido — exporta só o model
