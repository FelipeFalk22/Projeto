const Sequelize = require('sequelize');
const db = require('./conexao.js');

const ChamadoModel = db.define('chamado', {
  id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
  id_categoria: { type: Sequelize.INTEGER, allowNull: false },
  protocolo: { type: Sequelize.STRING(100), allowNull: false, unique: true },
  descricao: { type: Sequelize.TEXT, allowNull: true },
  status: { type: Sequelize.STRING(50), defaultValue: 'aberto' }
});

class Chamado {
  static findAllByCategoria(id_categoria) {
    return ChamadoModel.findAll({ where: { id_categoria } });
  }

  static create(data) {
    return ChamadoModel.create(data);
  }

  static update(dados, id_chamado, id_categoria) {
    return ChamadoModel.update(dados, {
      where: { id: id_chamado, id_categoria }
    });
  }

  static findOne(id_chamado, id_categoria) {
    return ChamadoModel.findOne({
      where: { id: id_chamado, id_categoria }
    });
  }

  static async delete(id_chamado, id_categoria) {
    const data = await ChamadoModel.findOne({
      where: { id: id_chamado, id_categoria }
    });
    if (!data) return false;
    await data.destroy();
    return true;
  }
}

module.exports = ChamadoModel;   // ✔ corrigido (igual aos outros models)
