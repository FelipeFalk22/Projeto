const express = require('express');
var router = express.Router();

const chamadoController = require('../controllers/ChamadoController.js');
const authMiddleware = require('../middlewares/TokenValido.js');

// ===============================
// CHAMADOS VINCULADOS À CATEGORIA
// ===============================

// LISTAR TODOS OS CHAMADOS
router.get('/', [authMiddleware.check], chamadoController.findAll);
/**
 * @swagger
 * /chamados:
 *   get:
 *     summary: Lista todos os chamados
 *     description: Retorna todos os chamados.
 *     tags: [Chamado]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista retornada com sucesso
 *       404:
 *         description: Nenhum chamado encontrado
 */

// Buscar detalhes de um chamado
router.get('/:id_chamado', [authMiddleware.check], chamadoController.findOne);
/**
 * @swagger
 * /chamados/{id_chamado}:
 *   get:
 *     summary: Obtém os detalhes de um chamado
 *     description: Retorna um único chamado pelo seu ID.
 *     tags: [Chamado]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id_chamado
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID do chamado
 *     responses:
 *       200:
 *         description: Detalhes retornados com sucesso.
 *       404:
 *         description: Chamado não encontrado.
 */

// Lista todos os chamados de uma categoria
router.get('/:id_categoria/chamados', [authMiddleware.check], chamadoController.findByCategoria);
/**
 * @swagger
 * /chamados/{id_categoria}/chamados:
 *   get:
 *     summary: Lista chamados de uma categoria
 *     description: Retorna todos os chamados associados a uma categoria.
 *     tags: [Chamado]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id_categoria
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID da categoria
 *     responses:
 *       200:
 *         description: Lista retornada com sucesso
 *       404:
 *         description: Nenhum chamado encontrado
 */

// Criar chamado dentro da categoria
router.post('/:id_categoria/chamados', [authMiddleware.check], chamadoController.create);
/**
 * @swagger
 * /chamados/{id_categoria}/chamados:
 *   post:
 *     summary: Cria um chamado dentro de uma categoria
 *     description: Cria um chamado vinculado à categoria informada.
 *     tags: [Chamado]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id_categoria
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/NovoChamado'
 *     responses:
 *       201:
 *         description: Chamado criado com sucesso
 *       400:
 *         description: Dados inválidos
 */

// Atualizar chamado
router.put('/:id_categoria/chamados/:id_chamado', [authMiddleware.check], chamadoController.update);
/**
 * @swagger
 * /chamados/{id_categoria}/chamados/{id_chamado}:
 *   put:
 *     summary: Atualiza um chamado
 *     description: Atualiza um chamado específico dentro de uma categoria.
 *     tags: [Chamado]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id_categoria
 *         required: true
 *         schema:
 *           type: integer
 *       - in: path
 *         name: id_chamado
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Chamado'
 *     responses:
 *       200:
 *         description: Chamado atualizado com sucesso
 *       404:
 *         description: Chamado não encontrado
 */

// Excluir chamado
router.delete('/:id_categoria/chamados/:id_chamado', [authMiddleware.check], chamadoController.delete);
/**
 * @swagger
 * /chamados/{id_categoria}/chamados/{id_chamado}:
 *   delete:
 *     summary: Exclui um chamado
 *     description: Remove um chamado específico da categoria informada.
 *     tags: [Chamado]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id_categoria
 *         required: true
 *         schema:
 *           type: integer
 *       - in: path
 *         name: id_chamado
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Chamado removido com sucesso
 *       404:
 *         description: Chamado não encontrado
 */

module.exports = router;
