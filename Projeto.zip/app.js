require('dotenv').config();              // Carrega variáveis de ambiente do .env
const express = require('express');
const cors = require('cors');
const config = require('./config.js');
const swaggerUi = require('swagger-ui-express');
const swaggerDocs = require('./swaggerConfig');

const app = express();

// --- MIDDLEWARES ---
app.use(express.json());                 // Permite receber JSON no corpo das requisições
app.use(cors({ origin: '*' }));          // Permite requisições de qualquer origem (CORS)

// --- DOCUMENTAÇÃO SWAGGER ---
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// --- ROTA RAIZ ---
app.get('/', (req, res) => {
  res.json({
    message: 'API - Sistema de Chamados de Suporte',
    version: '1.0',
  });
});

// --- ROTAS DA APLICAÇÃO ---
const categoriaRotas = require('./app/routes/categoria.routes.js');
const chamadoRotas = require('./app/routes/chamado.routes.js');
const usuarioRotas = require('./app/routes/usuario.routes.js');

app.use('/categorias', categoriaRotas);
app.use('/', chamadoRotas);
app.use('/', usuarioRotas);   // Rotas de usuário na raiz

// --- EXPORTAÇÃO ---
module.exports = app; // Exporta o app para ser usado em index.js ou testes
